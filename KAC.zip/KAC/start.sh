#!/bin/sh

python3 ./boot/main.py
