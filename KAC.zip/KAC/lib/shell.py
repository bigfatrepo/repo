
import os
import sys
import subprocess
import kacproc

class Shell:

    def func_cd(cmd, args):
        if len(args) == 0: print("Usage: cd PATH"); return
        path = args[0]
        if path[0] == "/" and os.path.isdir(path):
            os.chdir(path)
        elif os.path.isdir( os.path.join(os.getcwd(), path) ):
            os.chdir(path)
        else:
            print("{}: \x1b[31mnot a directory.".format(path))

    builtin_functions = {
        "cd": func_cd
    }

    def __init__(self, path):
        self.path = path


    def getfile(self, name):
        """Return path to file if found in `self.path`s,
otherwise empty string."""
        for p in self.path:
            file_ = os.path.join(p, name)
            if os.path.isfile( file_ ):
                return file_
        else:
            return ''

    def exists(self, name):
        if name in self.builtin_functions: return True
        r = self.getfile(name)
        return True if len(r)!=0 else False

    def run(self, cmd, args):
        if cmd in self.builtin_functions:
            self.builtin_functions[cmd](cmd, args)
        else:
            path = self.getfile(cmd)
            

            kacproc.run([path, *args])

        
