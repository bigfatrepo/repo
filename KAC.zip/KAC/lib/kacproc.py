import subprocess
import sys
import os

def run(cmd):
    p = subprocess.Popen(cmd)
    while True: # I really don't know what I am doing.
        try:
            p.wait()
            break
        except:
            pass
    return p.returncode

def fork(cmd):
	return subprocess.Popen(cmd).pid()
