#!/usr/bin/env python3
import sys, os
import time
import subprocess

# get system root dir
ROOT = os.getcwd()

logo = """\
\x1b[34m _  __          _____ 
| |/ /    /\   / ____|
| ' /    /  \ | |     
|  <    / /\ \| |     
| . \  / ____ \ |____ 
|_|\_\/_/    \_\_____|                     
\x1b[0m
Po prostu, kac.
KAC v0.1 20200505
\u201eJak złapie, to nie daruje.\u201c
"""

# Fancy displays
print("\x1b[H\x1b[2J", end="")
print(logo)

print("Root dir:")
print("  "+ROOT)

time.sleep(0.5)
print("\n")

# Setup environment.
os.chdir("./local")
os.environ["PYTHONPATH"] = ROOT+"/lib"
os.environ["KAC_ROOT"] = ROOT

# Run init script.
p = subprocess.Popen(["{}/bin/init".format(ROOT)])
while True: # fuck fuck fuck
    try:
        p.wait()
        break
    except:
        pass
#os.execvp("{}/bin/init".format(ROOT), [' '])

