#!/usr/bin/env python3
import os
import stat

import kacenv

print("Installing supercmd...")

install_path = os.path.join(kacenv.root, "bin/supercmd")

with open("./supercmd", 'rb') as f1:
    with open(install_path, 'wb') as f2:
        f2.write(f1.read())

# Make executable.
st = os.stat(install_path)
os.chmod(install_path, st.st_mode | stat.S_IEXEC)

print("Successfully installed supercmd.")

exit(0)
