#!/usr/bin/env python3
import os
import stat
try:
    import kacenv
except ImportError:
    print("installer: nie masz KACa")
    exit(255)
    
root = kacenv.root

print("Installing supercmd...")
install_path = os.path.join(root, "bin/supercmd")
with open("./supercmd", 'rb') as f1:
    with open(install_path, 'wb') as f2:
        f2.write(f1.read())

st = os.stat(install_path)
os.chmod(install_path, st.st_mode | stat.S_IEXEC)
print("Done.")
