#!/usr/bin/env python3
import os
import stat
try:
    import susenv
except ImportError:
    print("installer: not in SUS system")
    exit(255)
    
root = susenv.root

print("Installing supercmd...")
install_path = os.path.join(root, "bin/supercmd")
with open("./supercmd", 'rb') as f1:
    with open(install_path, 'wb') as f2:
        f2.write(f1.read())

st = os.stat(install_path)
os.chmod(install_path, st.st_mode | stat.S_IEXEC)
print("Done.")
