#!/usr/bin/env python3

print("Fucking erroe oh noouuuu!!!!!")
exit(69)
