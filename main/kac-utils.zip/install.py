#!/usr/bin/env python3
import kacenv
import kacos
import shutil
import os

for name in os.listdir("./bin"):
    shutil.copyfile(os.path.join("bin", name), kacenv.path("^/bin/"+name))
    kacos.mark_executable(kacenv.path("^/bin/"+name))

