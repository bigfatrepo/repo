#!/usr/bin/env python3
# ======== Hello ==========
# This script should be called from KAC root.
# e.g.
# $ cd KAC
# $ python3 ./boot/main.py
# =========================
import sys, os
import time
import subprocess

from pathlib import Path

# get system root dir
ROOT = Path(".").resolve()

logo = """\
\x1b[34m _  __          _____ 
| |/ /    /\   / ____|
| ' /    /  \ | |     
|  <    / /\ \| |     
| . \  / ____ \ |____ 
|_|\_\/_/    \_\_____|                     
\x1b[0m
Po prostu, kac.
KAC v0.1.1
\u201eJak złapie, to nie daruje.\u201c
"""

# Fancy displays
print("\x1b[H\x1b[2J", end="")
print(logo)

print("Root dir:")
print("  "+os.fspath(ROOT))

time.sleep(0.5)
print("\n")

# Setup environment.
os.chdir(ROOT/'local')
os.environ["PYTHONPATH"] = os.fspath(ROOT/'lib')
os.environ["KAC_ROOT"] = os.fspath(ROOT)

# Run init script.
try:
    # Init script.
    p = subprocess.Popen([ os.fspath(ROOT/'bin'/'init') ])
except FileNotFoundError:
    print("\x1b[31;1m^/bin/init not found.")
    exit(1)
except PermissionError:
    print("\x1b[33;1m^/bin/init not executable.")
    exit(1)

# Wait for untill process terminates.
while True:
    # Hack for p.wait() throwing KeyboardInterrupts.
    try:
        p.wait()
        break
    except:
        pass
