#!/usr/bin/env python3
import kacenv
import kacos
import shutil

shutil.copyfile("./main.py", kacenv.path("^/boot/main.py"))
kacos.mark_executable(kacenv.path("^/boot/main.py"))

