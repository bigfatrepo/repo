#!/usr/bin/env python3
import kacenv
import kacos
import shutil

shutil.copyfile("./doc", kacenv.path("^/bin/doc"))
kacos.mark_executable(kacenv.path("^/bin/doc"))

