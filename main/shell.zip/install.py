#!/usr/bin/env python3
import kacenv
import kacos
import shutil

shutil.copyfile("./shell", kacenv.path("^/bin/shell"))
kacos.mark_executable(kacenv.path("^/bin/shell"))

shutil.copyfile("./shell.py", kacenv.path("^/lib/shell.py"))

