#!/usr/bin/env python3
import kacenv
import kacos
import shutil

shutil.copyfile("./wiki", kacenv.path("^/bin/wiki"))
kacos.mark_executable(kacenv.path("^/bin/wiki"))

