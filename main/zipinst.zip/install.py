#!/usr/bin/env python3
import kacenv
import kacos
import shutil

shutil.copyfile("./zipinst", kacenv.path("^/bin/zipinst"))
kacos.mark_executable(kacenv.path("^/bin/zipinst"))

