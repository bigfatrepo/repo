#!/usr/bin/env python3
import kacenv
import kacos
import shutil

shutil.copyfile("./pkglib.py", kacenv.path("^/lib/pkglib.py"))

shutil.copyfile("./pkg", kacenv.path("^/bin/pkg"))
kacos.mark_executable(kacenv.path("^/bin/pkg"))

