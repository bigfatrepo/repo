import requests


def get_package(path, name):
    from shlex import split
    with open(path, 'r') as f:
        found = ""
        while True:
            line = f.readline()
            if not line: break
            if not line.strip(): continue
            if line[0] == "#": continue
            entry = split(line)
            if entry[-2] == name: found = entry; break

        if found == "":
            return {}
        else:
            pkg = {
                "protocol": found[0],
                "url": found[1],
                "name": found[2],
                "version": found[3]
            }
            return pkg

def _str_version_uptodate(s1, s2):
    """s1 - installed, s2 - to compare"""
    l1 = [ int(i) for i in s1.split('.') ]
    l2 = [ int(i) for i in s2.split('.') ]
    if l1 >= l2: return False
    else: return True
        
def get_packages_status(installed_path, index_path):
    import os
    from ast import literal_eval

    r = {
        "ok": [],
        "upgradable": [],
        "not-in-index": []
    }
    
    # Check every installed package.
    for fname in os.listdir(installed_path):
        # Path to single installed package .dict.
        fpath = os.path.join(installed_path, fname)

        # Read and eval .dict
        with open(fpath, 'r') as f:
            pkg_installed = literal_eval(f.read())
        
        pkg_index = get_package(index_path, pkg_installed["name"])
        if pkg_index == {}:
            r["not-in-index"].append(pkg_installed["name"])
            
        elif _str_version_uptodate(pkg_installed["version"], pkg_index["version"]):
            r["upgradable"].append(pkg_installed["name"])

        else:
            r["ok"].append(pkg_installed["name"])

    return r

def download_http(url, path):
    with requests.get(url, stream=True) as r:
        r.raise_for_status()
        #size = r.headers["content-length"]
        
        with open(path, 'wb') as f:
            c = 0
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)
                c += len(chunk)
                print("\x1b[2K\x1b[1000D{}".format(c), end="", flush=True)
            print("\x1b[2K\x1b[1000DDownloaded {} bytes.".format(c))

def download(protocol, url, path):
    if protocol in ("direct", "http", "https", "ftp"):
        download_http(url, path)

def install(path):
    import kacproc
    import kacenv
    import os
    kacproc.run([
        os.path.join(kacenv.root, "bin/zipinst"), path])


def remove(path):
    from ast import literal_eval
    import os
    import kacenv
    
    with open(path, 'r') as f:
        pkg = literal_eval(f.read())

    x = input("Do you want to remove \x1b[34;1m{}\x1b[0m? [Y/n]".format(pkg["name"]))
    if x in ("Y", "y", ""):
        files = pkg["files"]
        for fpath in files:
            fullpath = kacenv.kacpath(fpath)
            
            if os.path.isfile(fullpath):
                print("Removing file", fpath)
                os.remove(fullpath)
            elif os.path.isdir(fullpath):
                print("Removing dir", fpath)
                os.rmdir(fullpath)
            else:
                print("Already removed", fpath)

        os.remove(path)
    else:
        print("Abort.")
