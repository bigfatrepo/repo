#!/usr/bin/env python3
import kacenv
import shutil

shutil.copyfile("./ttyin.py", kacenv.path("^/lib/ttyin.py"))

