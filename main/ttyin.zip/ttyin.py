# ttyin v1.0 20200415
# TTYin - i mean it was just for the input to make reading sequences easier
#         but it's got also handy write() and flush()


# _ = TTYin(sys.stdin, sys.stdout)

# KEYS_SPECIAL - dict of esc sequence names

#tty
# setraw() - set tty to some raw mode, check code for more info
# setdef() - set tty back to previous state

#stdin
# read() - read from stdin up to 6 characters, check KEYS_SPECIAL

#stdout
# write(s, flush=True) - write str string to stdout and flush by default
# flush() - flush stdout
import sys, os, termios
import time


class TTYin:

    KEYS_SPECIAL = {
        b"\x1b": "esc",
        b"\x1bOP": "f1",
        b"\x1bOQ": "f2",
        b"\x1bOR": 'f3',
        b"\x1bOS": 'f4',
        b"\x1b[15~": 'f5',
        b"\x1b[17~": 'f6',
        b"\x1b[18~": 'f7',
        b"\x1b[19~": 'f8',
        b"\x1b[20~": 'f9',
        b"\x1b[21~": 'f10',
        b"\x1b[23~": 'f11',
        b"\x1b[24~": 'f12',

        b"\x1b[H": 'home',
        b"\x1b[F": 'end',
        b"\x1b[2~": 'insert',
        b"\x1b[3~": 'delete',
        b"\x1b[5~": 'pageup',
        b"\x1b[6~": 'pagedown',

        b"\t": 'tab',
        b"\x7f": 'backspace',
        b"\n": 'enter',

        b"\x1b[A": 'up',
        b"\x1b[B": 'down',
        b"\x1b[C": 'right',
        b"\x1b[D": 'left',
        
    }
    
    def __init__(self, stdin, stdout, stderr=None):
        self.stdin  = stdin
        self.stdout = stdout
        fd = self.stdin.fileno()
        self.stdin_default = termios.tcgetattr(fd)

    def setraw(self):
        fd = self.stdin.fileno()
        stdin_new = termios.tcgetattr(fd)
        stdin_new[3] = stdin_new[3] & ~( termios.ECHO | termios.IGNBRK | termios.BRKINT | termios.PARMRK | termios.ISTRIP | termios.INLCR | termios.IGNCR | termios.IXON)
        stdin_new[6][termios.VMIN] = 1
        stdin_new[6][termios.VTIME] = 0
        termios.tcsetattr(fd, termios.TCSANOW, stdin_new)

    def setdef(self):
        fd = self.stdin.fileno()
        termios.tcsetattr(fd, termios.TCSANOW, self.stdin_default)


    def read(self):
        return os.read(self.stdin.fileno(), 6)

    def write(self, s, flush=True):
        self.stdout.write(s)
        if flush: self.stdout.flush()

    def flush(self):
        self.stdout.flush()


    def clear(self):
        self.write("\x1b[2J\x1b[H")

    def cursor_move(self, x, y=0):
        if x != 0:
            if x > 0:
                self.write("\x1b[{}C".format(x))
            else:
                self.write("\x1b[{}D".format(abs(x)))
        
        if y != 0:
            if y > 0:
                self.write("\x1b[{}A".format(y))
            else:
                self.write("\x1b[{}B".format(abs(y)))

    def cursor_setpos(self, x, y):
        self.write("\x1b[{};{}H".format(y, x))





if __name__ == "__main__":
    tty = TTYin(sys.stdin, sys.stdout)
    tty.setraw()
    try:
        while True:
            x = tty.read()
            tty.write(str(x)[2:-1], flush=0)
            tty.write("\n")
            if x == b"\x1b": print("aaaa"); time.sleep(2); break
            if x in tty.KEYS_SPECIAL:
                tty.write(tty.KEYS_SPECIAL[x])
    except Exception as e:
        tty.setdef()
        print(e)
        input("err")
    finally:
        tty.setdef()
    

