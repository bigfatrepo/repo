import subprocess
import kacenv
import sys
import os

def run(cmd):
    pyexecflag = kacenv.flag("pyexec")
    
    if pyexecflag == 0:
        p = subprocess.Popen(cmd)
    elif pyexecflag == 1:
        p = subprocess.Popen(["python3"]+cmd)
    
    while True: # I really don't know what I am doing.
        try:
            p.wait()
            break
        except:
            pass
    return p.returncode

def fork(cmd):
    pyexecflag = kacenv.flag("pyexec")
    if pyexecflag == 0:
	    return subprocess.Popen(cmd).pid()
    elif pyexecflag == 1:
        return subprocess.Popen(["python3"]+cmd).pid()
