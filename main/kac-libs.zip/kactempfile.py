import tempfile
import os
import kacenv

temp_dir = os.path.join(kacenv.root, "tmp")

def mktemp(mode="w", directory=False):
    for i in range(100):
        temp_name = next(tempfile._get_candidate_names())
        if os.path.exists( os.path.join(temp_dir, temp_name) ):
            continue
        else:
            temp_path = os.path.join(temp_dir, temp_name)
            break
    else:
        print("\x1b[31mKatalog \x1b[33m/tmp \x1b[31mw KAC jest tak zasyfiony, że system się rozpierdolił.\x1b[0m")
        exit(69)

    if directory:
        os.mkdir( temp_path )
        return temp_path
    else:
        f = open(temp_path, mode)
        return f
