import tempfile
import os
import kacenv
from pathlib import Path

temp_dir = kacenv.Root / "tmp"

def mktemp(mode="w", directory=False):
    for i in range(100):
        temp_name = next(tempfile._get_candidate_names())
        if Path(temp_dir / temp_name).exists():
            continue
        else:
            temp_path = Path(temp_dir / temp_name)
            break
    else:
        print("\x1b[31mKatalog \x1b[33m/tmp \x1b[31mw KAC jest tak zasyfiony, że system się rozpierdolił.\x1b[0m")
        exit(69)

    if directory:
        temp_path.mkdir()
        return temp_path
    else:
        f = open(temp_path, mode)
        return f
