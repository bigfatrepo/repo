import os
from pathlib import Path

root = os.environ["KAC_ROOT"]
Root = Path(os.environ["KAC_ROOT"])
flags = [ int(i) for i in os.environ["KAC_FLAGS"] ]

# KAC Path Prefix™
# Paths prefixed with that character will be treated
# as paths from KAC root, instead from host OS's root.
# BUT: only in supported programs, config files, etc.
#   It has to be very safe in case of a mistake, where it'll
#   throw an error instead of writing to some random file,
#   and possibly causing data loss.
path_prefix = "^"


def path(path):
    if path[0:2] == path_prefix+"/":
        return Path( os.path.join(root, path[2:]) )
    else:
        return Path( path )

def flag(key):
    keys = {
        "pyexec": 0
    }

    return flags[keys[key]]
