#!/usr/bin/env python3
import kacenv
import kacos
import shutil

files = [
    "kacenv.py",
    "kacos.py",
    "kacproc.py",
    "kactempfile.py"
]

for i in files:
    shutil.copyfile(i, kacenv.path("^/lib/"+i))


